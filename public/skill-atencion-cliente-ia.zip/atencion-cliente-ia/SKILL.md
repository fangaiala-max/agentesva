---
name: atencion-cliente-ia
description: Redacta respuestas de atención al cliente on-brand (email, WhatsApp, reseñas de Google, reclamaciones) en español, a partir del mensaje del cliente y una breve guía de tono del negocio. Úsala cuando haya que contestar a un cliente y quieras hacerlo rápido, con la voz de tu marca y sin sonar a robot.
---

# Atención al cliente con IA

## Cuándo usarla

Cuando tienes delante el mensaje de un cliente (una duda, una queja, una reseña) y quieres contestar rápido, con la voz de tu marca y sin que suene a plantilla robótica.

## Qué necesito de ti

Si no viene en el mensaje, te lo pido antes de escribir:

- **Sector / negocio**: a qué te dedicas (tienda de ropa, taller, consultoría…).
- **Tono deseado**: cercano, formal, resolutivo… (una frase basta; ver `referencia/tono-y-voz.md`).
- **Canal**: email, WhatsApp, reseña de Google o reclamación.
- **Datos clave**: solo los que hagan falta para responder (política de devoluciones, plazos, precios, horarios). Si no me los das, los dejo marcados.
- **El mensaje del cliente**: pégamelo tal cual.

Si te falta algún dato, no lo invento: te devuelvo la respuesta con `[dato]` para que lo completes.

## Cómo trabajo

1. **Detecto canal e intención**: leo el mensaje y clasifico (pre-venta, incidencia, reseña, reclamación) y el canal.
2. **Cargo la plantilla del canal** desde `plantillas/` (`email.md`, `whatsapp.md`, `resena-google.md` o `reclamacion.md`).
3. **Aplico la guía de tono** de `referencia/tono-y-voz.md` según lo que me hayas pedido.
4. **Entrego 2 variantes**: una **breve** (directa, para responder ya) y una **completa** (más contexto y cuidado). Debajo, una **nota de 1 línea** que explica cuándo usar cada una.
5. **Marco entre `[corchetes]`** todo lo que debes personalizar o rellenar antes de enviar.

## Reglas

- **Nunca invento datos** (precios, plazos, políticas). Si faltan, dejo `[dato]` en su sitio.
- **No prometo lo que la política no permite**: si no sé si algo es posible, lo dejo condicional o marcado.
- **Español de España por defecto.** Si me pides variante LATAM neutro, adapto vocabulario y trato (sin "vosotros", tuteo o "usted" neutro) manteniendo la misma estructura.
- Mantengo la respuesta al grano: el objetivo es que el cliente se sienta atendido, no abrumado.

## Recursos

Consulta `referencia/tono-y-voz.md` para fijar el registro y `plantillas/` para la estructura de cada canal. Ejemplos trabajados (entrada → salida) en `ejemplos/`.
