# Atención al cliente con IA · AgentesVA (gratis)

Skill de Claude que redacta respuestas de atención al cliente **on-brand** en español,
a partir del mensaje del cliente y una breve guía de tono de tu negocio. Rápida, con la
voz de tu marca y sin sonar a robot.

## Qué hace

Le das el mensaje de un cliente (una duda, una queja, una reseña) y una frase que
describe tu tono. La skill detecta el canal, elige la plantilla adecuada y te devuelve
**2 variantes** de respuesta (una breve y una completa) más una nota de cuándo usar cada
una. Nunca inventa datos: lo que no le des (precios, plazos, políticas) lo deja marcado
entre `[corchetes]` para que lo completes antes de enviar.

Canales que cubre: **email**, **WhatsApp**, **reseñas de Google** y **reclamaciones**.

## Qué incluye

- `SKILL.md` — las instrucciones de la skill (lo que Claude lee).
- `referencia/tono-y-voz.md` — cómo describir tu tono y mantener la voz de marca.
- `plantillas/` — estructura lista para cada canal (`email`, `whatsapp`, `resena-google`, `reclamacion`).
- `ejemplos/` — casos resueltos de principio a fin (pre-venta, reclamación, reseña negativa).

## Cómo instalarla

Consulta el [README raíz](../../README.md). En resumen:

1. Descomprime el zip que descargaste.
2. Copia la carpeta `atencion-cliente-ia/` a tu directorio de skills de Claude (por
   ejemplo, `~/.claude/skills/`).
3. Reinicia o activa Claude para que la detecte.

## Cómo usarla

Basta con describir la tarea. Por ejemplo:

> Ayúdame a responder esta reseña de Google. Somos una cafetería, tono cercano y
> tuteando. La reseña dice: *"Buen café pero el camarero estuvo bastante seco. 3 estrellas."*

Claude reconocerá el canal (reseña), aplicará tu tono y te dará dos variantes de
respuesta pública, con `[marcadores]` para lo que debas personalizar.

Si te falta algún dato (un precio, un plazo), no te preocupes: la skill te lo pide o lo
deja marcado. Tú solo completas y envías.

---

AgentesVA · [agentesva.com](https://agentesva.com) — Skills de IA en español para PyMEs.
Uso sujeto a [`LICENSE-USO.md`](../../LICENSE-USO.md).
