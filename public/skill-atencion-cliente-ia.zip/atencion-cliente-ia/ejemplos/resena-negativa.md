# Ejemplo · Reseña negativa (2★ en Google)

Reseña pública de 2 estrellas. La respuesta la leerá mucha gente que valora si venir.
Objetivo: desescalar, no discutir, y llevar el caso a privado.

## Entrada

**Contexto**: Restaurante. Tono cercano pero cuidado, tuteo. Canal: respuesta pública
a reseña de Google.

**Reseña del cliente (2★)**:
> Fuimos un sábado y tardaron muchísimo en servir. La comida bien, pero esperamos casi
> una hora los platos. Una pena porque el sitio promete.

## Salida trabajada

**Canal detectado**: reseña de Google · **Intención**: queja pública (servicio lento) → desescalar y pasar a privado.

### Variante corta

> Hola [Nombre], gracias por tu comentario y sentimos mucho la espera del sábado. No es la experiencia que queremos dar. Nos encantaría invitarte a que nos des otra oportunidad: escríbenos a [email/teléfono] y lo organizamos.
>
> — [Nombre] · [Negocio]

### Variante completa

> Hola [Nombre], gracias por tomarte el tiempo de escribirnos, y lamentamos de verdad la espera de casi una hora. Nos alegra que la comida te gustara, pero un tiempo así no es aceptable y es justo lo que estamos revisando en el servicio de los sábados.
>
> Nos gustaría compensarte y que vuelvas a vernos en mejores condiciones. ¿Nos escribes a [email/teléfono] indicando la fecha de tu visita? Así lo miramos en detalle y lo arreglamos contigo.
>
> — [Nombre] · [Negocio]

**Nota**: la **corta** desescala en dos líneas (ideal si respondes muchas reseñas); la **completa** reconoce el punto concreto y demuestra públicamente que os lo tomáis en serio. Ninguna discute ni da datos del cliente en abierto: ambas mueven la conversación a un canal privado.
