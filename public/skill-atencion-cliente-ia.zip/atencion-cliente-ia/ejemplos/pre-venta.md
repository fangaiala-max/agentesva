# Ejemplo · Pre-venta (email)

Un cliente pregunta por disponibilidad y precio antes de comprar. No tenemos aún el
precio confirmado, así que se queda marcado — no se inventa.

## Entrada

**Contexto**: Estudio de fotografía. Tono cercano y profesional, tuteo. Canal: email.
No hay tarifa cerrada para este pack todavía.

**Mensaje del cliente**:
> Hola, estoy buscando un fotógrafo para una sesión de familia en exteriores para
> mediados de julio. ¿Tenéis hueco? ¿Y cuánto costaría más o menos? Gracias.

## Salida trabajada

**Canal detectado**: email · **Intención**: pre-venta (disponibilidad + precio).

### Variante corta

> **Asunto:** Re: sesión de familia en julio
>
> Hola [Nombre]:
>
> ¡Gracias por escribirnos! Sí, tenemos hueco a mediados de julio para una sesión de familia en exteriores. La sesión de este tipo cuesta [dato: precio del pack].
>
> Dime qué día te vendría bien y te confirmo la reserva.
>
> Un saludo,
> [Nombre] · [Negocio]

### Variante completa

> **Asunto:** Re: sesión de familia en exteriores — disponibilidad julio
>
> Hola [Nombre]:
>
> ¡Gracias por pensar en nosotros para vuestra sesión de familia! Nos encanta trabajar en exteriores en verano.
>
> Para mediados de julio tenemos disponibilidad. El pack de sesión familiar en exteriores incluye [dato: qué incluye — duración, nº de fotos editadas] y tiene un precio de [dato: precio]. Si buscáis algo a medida, también lo vemos sin problema.
>
> Cuéntame qué fecha os viene mejor y si sois muchos en la familia, y te confirmo el hueco y te paso todos los detalles.
>
> Cualquier duda, aquí me tienes.
>
> Un saludo,
> [Nombre] · [Negocio]
> [Teléfono / web]

**Nota**: usa la **corta** si quieres responder ya y cerrar fecha; la **completa** en una primera toma de contacto, cuando conviene transmitir cuidado y vender el pack. En ambas, el precio queda como `[dato]` porque no estaba confirmado: complétalo antes de enviar.
