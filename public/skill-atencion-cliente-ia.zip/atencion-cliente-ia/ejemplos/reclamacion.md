# Ejemplo · Reclamación (pedido tardío o dañado)

Un pedido llega tarde y en mal estado. El cliente está molesto. Respuesta con empatía,
acción concreta y plazo — sin inventar tiempos que no controlamos.

## Entrada

**Contexto**: Tienda online de vajilla artesanal. Tono cercano y resolutivo, tuteo.
Canal: email. Política: reemplazo gratuito de piezas dañadas; el plazo de envío del
reemplazo no está confirmado.

**Mensaje del cliente**:
> Pedí un juego de platos hace dos semanas para un regalo y me ha llegado hoy, tarde,
> y encima con dos platos rotos. Un desastre. Quiero una solución ya.

## Salida trabajada

**Canal detectado**: email · **Intención**: reclamación (retraso + producto dañado).

### Variante corta

> Hola [Nombre]:
>
> He recibido tu reclamación por el retraso y los dos platos rotos, y lo siento de veras.
>
> Esto es lo que hacemos: te enviamos dos platos nuevos sin coste. Solo necesito que me confirmes la dirección de entrega. Calculo que los tendrás en [plazo].
>
> Te aviso en cuanto salgan. Un saludo,
> [Nombre] · [Negocio]

### Variante completa

> Hola [Nombre]:
>
> He recibido tu reclamación y la he registrado: pedido con retraso y dos platos rotos a la llegada. Entiendo perfectamente el disgusto, más aún tratándose de un regalo, y lo siento.
>
> Esto es lo que vamos a hacer:
> - Te enviamos dos platos nuevos, sin ningún coste para ti.
> - Confírmame la dirección de entrega y me encargo del envío hoy mismo.
>
> Calculo que los recibirás en [plazo]; en cuanto salgan, te paso el seguimiento. Como disculpa por las molestias, [dato: compensación si tu política la contempla — si no, borra esta línea].
>
> Cualquier cosa mientras tanto, escríbeme a [email/teléfono] y lo resolvemos.
>
> Un saludo,
> [Nombre] · [Negocio]

**Nota**: la **corta** va al grano para un cliente que solo quiere la solución; la **completa** suma empatía, seguimiento y posible compensación para desactivar el enfado. El plazo queda como `[plazo]` porque no estaba confirmado: no prometas una fecha que no controlas.
