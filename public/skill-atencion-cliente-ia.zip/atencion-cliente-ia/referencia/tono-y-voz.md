# Tono y voz

Guía práctica para fijar el registro de tus respuestas. El objetivo: que suenen a tu
negocio y no a un formulario.

## Describe tu tono en una frase

Piensa en tres ejes y elige un punto de cada uno:

- **Cercanía**: distante ←→ cercano (¿tuteas o tratas de usted?).
- **Formalidad**: coloquial ←→ formal (¿lenguaje de la calle o de oficina?).
- **Energía**: sereno ←→ enérgico (¿tranquilo y sobrio o entusiasta con signos de exclamación?).

Ejemplo de frase de tono: *"Cercano y tranquilo, tuteo, sin tecnicismos, cero exclamaciones."*
Con eso me basta para calibrar todas las respuestas.

## Registros de ejemplo

**1. Cercano y cálido** (tienda de barrio, hostelería)
Saludo: "¡Hola, Marta! Qué bien tenerte por aquí." · Despedida: "Un abrazo y hasta pronto."

**2. Profesional y resolutivo** (servicios B2B, agencias)
Saludo: "Hola, Marta, gracias por escribirnos." · Despedida: "Quedo a tu disposición. Un saludo."

**3. Formal y de usted** (asesorías, sector legal/salud)
Saludo: "Estimada Sra. López, gracias por su mensaje." · Despedida: "Reciba un cordial saludo."

**4. Fresco y directo** (marcas jóvenes, e-commerce)
Saludo: "¡Hey, Marta!" · Despedida: "¡Nos vemos! 🙌"

**5. Sobrio y neutro** (LATAM neutro, público mixto)
Saludo: "Hola, Marta, gracias por tu mensaje." · Despedida: "Saludos cordiales."

## Cómo mantener la consistencia de marca

- Elige **un** registro y úsalo en todos los canales (adaptando el largo, no el carácter).
- Reutiliza siempre el mismo saludo y la misma despedida: crean reconocimiento.
- Firma igual siempre: `[Nombre] · [Negocio]`.

## Errores a evitar

- **Sonar a plantilla**: frases como "su llamada es muy importante para nosotros" enfrían. Habla como una persona.
- **Exceso de disculpas**: pedir perdón tres veces resta credibilidad. Una disculpa sincera + solución.
- **Tecnicismos y jerga**: escribe para el cliente, no para tu sector.
- **Muros de texto**: párrafos cortos, una idea por línea. Se lee mejor y transmite cuidado.
- **Prometer de más**: si no estás seguro de un plazo o condición, déjalo marcado (`[dato]`), no lo inventes.
