# Plantilla · Reseña de Google (respuesta pública)

La lee el cliente y, sobre todo, quien busca tu negocio. Agradece, personaliza, sé
breve y transmite que hay personas detrás. Si es una queja, desescala y lleva la
conversación a privado.

---

## Reseña positiva

Hola [Nombre], ¡gracias por tu reseña! [Personaliza: menciona algo concreto que comentó, ej. "nos alegra que disfrutaras del [plato/servicio]".]

[Cierre cálido + invitación a volver. Ej.: "Te esperamos pronto por [Negocio]."]

— [Nombre] · [Negocio]

---

## Reseña negativa

Hola [Nombre], gracias por tomarte el tiempo de contarnos tu experiencia y lamentamos que no fuera la esperada.

[Reconoce el punto concreto sin excusas ni discusión pública. 1 frase.]

Nos gustaría revisarlo contigo y darte una solución. ¿Nos escribes a [email/teléfono] indicando [dato: nº de pedido / fecha]? Así lo vemos en detalle.

— [Nombre] · [Negocio]

---

**Reglas de la respuesta pública**

- Breve: 2-4 líneas. Nadie lee reseñas largas.
- Nunca discutas ni des datos del cliente en público.
- En quejas, el objetivo es **desescalar y pasar a privado**, no ganar la razón.

**Variante corta / Variante completa**

- **Corta**: agradecimiento + una frase personalizada. Para reseñas de 4-5★ sin queja.
- **Completa**: añade reconocimiento del punto concreto + canal privado. Para reseñas con matiz negativo o de 1-3★.
