# Plantilla · Email

Estructura de una respuesta por email. Rellena los `[marcadores]` y borra lo que no uses.

---

**Asunto:** [Re: asunto original o resumen en 4-6 palabras]

Hola [Nombre]:

[Reconocimiento: agradece el mensaje o reconoce la situación en 1 frase. Ej.: "Gracias por escribirnos" / "Lamento el inconveniente con tu pedido".]

[Respuesta / solución: contesta la pregunta o explica qué se va a hacer. Sé concreto. Usa los datos clave del negocio; si falta alguno, déjalo como [dato].]

[Siguiente paso: dile al cliente qué hacer ahora o qué esperar. Ej.: "Te confirmo la reserva en cuanto me digas la fecha" / "Puedes completar la compra en [enlace]".]

Cualquier otra duda, aquí me tienes.

Un saludo,
[Nombre] · [Negocio]
[Teléfono / web / horario opcional]

---

**Variante corta / Variante completa**

- **Corta**: asunto + saludo + respuesta directa + despedida. Para dudas simples o clientes que quieren rapidez.
- **Completa**: incluye reconocimiento y siguiente paso detallado. Para primeras impresiones, temas delicados o cuando conviene dejar todo por escrito.
