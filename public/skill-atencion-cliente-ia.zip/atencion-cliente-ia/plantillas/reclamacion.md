# Plantilla · Reclamación

Cuando algo ha salido mal (pedido tardío, dañado, cobro incorrecto). El cliente quiere
sentirse escuchado y saber qué va a pasar y cuándo. Empatía + acción concreta.

---

Hola [Nombre]:

[Acuse de recibo: confirma que has recibido y entendido la reclamación. Ej.: "He recibido tu reclamación sobre [asunto] y la he registrado."]

[Empatía: reconoce la molestia sin sobreactuar. Una frase. Ej.: "Entiendo que esto no es lo que esperabas y lo siento."]

Esto es lo que vamos a hacer:
[Qué haremos: pasos concretos. Ej.: "Revisar el pedido [nº] y enviarte el reemplazo."]

[Plazo: cuándo tendrá noticias o solución. Si no lo sabes con certeza, deja [plazo] sin inventarlo.]

[Compensación si aplica: solo si tu política la contempla. Ej.: "Como disculpa, aplicamos [dato: descuento / envío gratis]." Si no aplica, borra esta línea.]

Te iré informando por aquí. Si necesitas algo mientras tanto, escríbeme a [email/teléfono].

Un saludo,
[Nombre] · [Negocio]

---

**Variante corta / Variante completa**

- **Corta**: acuse + qué haremos + plazo. Para reclamaciones sencillas y clientes que quieren solución, no relato.
- **Completa**: añade empatía explícita, compensación y canal de seguimiento. Para incidencias serias, clientes molestos o casos que pueden escalar.
