# Plantilla · WhatsApp

Mensaje corto, tono cercano, se lee en el móvil de un vistazo. Máximo 1 emoji (opcional).
Nada de párrafos largos: 2-4 líneas.

---

Hola [Nombre] 👋 [saludo + reconocimiento en una línea]

[Respuesta o solución en 1-2 líneas. Concreta. Si falta un dato, déjalo como [dato].]

[CTA claro: una sola acción. Ej.: "¿Te reservo mesa para [fecha]?" / "Te paso el enlace: [enlace]".]

---

**Notas de canal**

- Un solo emoji como máximo, y solo si encaja con tu tono. Si dudas, ninguno.
- Evita el "usted" salvo que tu marca sea muy formal; WhatsApp pide cercanía.
- No metas la firma completa: basta con el nombre del negocio si hace falta.

**Variante corta / Variante completa**

- **Corta**: saludo + respuesta + CTA en 2-3 líneas. Lo habitual en WhatsApp.
- **Completa**: añade un dato de contexto o una segunda opción. Úsala solo si el cliente pidió detalle; si no, cuanto más breve, mejor.
